SC.initialize({
  client_id: '6ffd5714efc7c32a70e03dabd8137cbc'
});

$(document).ready(function() {

	// set initial $nebulaButton    
    var $nebulaButton = $('.current-nebula a');
	// set the index for the tracks offset var
    

    // colorScheme object
    var colorScheme1 = { 	dark : '#BF736D', 
						    medium : '#EAB3AD',
						    light : '#EFCCCA',
						    nebula : 'http://apod.nasa.gov/apod/image/1102/rosette_lula_1700.jpg' 
						};
    var colorScheme2 = { 	dark : '#744D54',
						    medium : '#97797F', 
						    light : '#B9A6A9',
						    nebula : 'http://apod.nasa.gov/apod/image/0710/EtacarinaeSGL_gendler.jpg' 							    
						};
    var colorScheme3 = { 	dark : '#616E76',
						    medium : '#B0B7BB', 
						    light : '#D7DBDD',
						    nebula : 'http://apod.nasa.gov/apod/image/0601/llori_orion_hst_f.jpg' 							    
						};
    var colorScheme4 = { 	dark : '#616E76',
						    medium : '#B0B7BB', 
						    light : '#D7DBDD',
						    nebula : 'http://d1jqu7g1y74ds1.cloudfront.net/wp-content/uploads/2010/08/Dark-Clouds-of-the-Carina-Nebula.jpg' 							    
						};
    var colorScheme5 = { 	dark : 'blue',
						    medium : 'orange', 
						    light : 'gray',
						    nebula : 'http://apod.nasa.gov/apod/image/0601/llori_orion_hst_f.jpg' 							    
						};
    var colorScheme6 = { 	dark : '#BF736D', 
						    medium : '#EAB3AD',
						    light : '#EFCCCA',
						    nebula : 'http://apod.nasa.gov/apod/image/1102/rosette_lula_1700.jpg' 
						};
    var colorScheme7 = { 	dark : '#BF736D',
						    medium : 'white', 
						    light : '#EFCCCA',
						    nebula : 'http://pdphoto.org/jons/external/57329_151_jwfull.jpg' 							    
						};
    var colorScheme8 = { 	dark : 'blue',
						    medium : 'orange', 
						    light : 'gray',
						    nebula : 'http://apod.nasa.gov/apod/image/0601/llori_orion_hst_f.jpg' 							    
						};
    var colorScheme9 = { 	dark : 'blue',
						    medium : 'orange', 
						    light : 'gray',
						    nebula : 'http://apod.nasa.gov/apod/image/0601/llori_orion_hst_f.jpg' 							    
						};
    var colorScheme10 = { 	dark : 'blue',
						    medium : 'orange', 
						    light : 'gray',
						    nebula : 'http://apod.nasa.gov/apod/image/0601/llori_orion_hst_f.jpg' 							    
						};

	


	function clearResults() {
		// First, let's clear the area if there were previous results from other nebulas:
		$('#results').html('');

		// // Clear the Results Area before repopulating
		// if ($('#results li').length > 0 ) {
		// 	$('#results').html('');
		// 	//console.log($('#results li').length);
		// }	
	}


	/*
	** Set currentNebula allows the initial set up of the #results. It populates the tracks,
	*/ 
	function setCurrentNebula () {	
		clearResults();
		i = 0;
		var i = 4;			
		// clear #results div
		

		console.log('results cleared and i = ' + i);

		

		// Initialize BPM and nebula variables			
		var $currentNebula = $('.current-nebula a');

		var nebula = $currentNebula.text();
		var nebulaForScroll = $currentNebula.text();
		var minBpm = $currentNebula.attr('data-min-bpm');
		var maxBpm = $currentNebula.attr('data-max-bpm');

		// define search filters for SC api
		var filterTracks = {   
			bpm: { from: minBpm, to: maxBpm }, 
			//filter: 'downloadable', 
			//tags: tagList, 
			genres: 'psytrance',
			//q: 'dark',
			//types: 'original',
			//order: 'created_at',
			limit: 100,
			offset: 0	
			};

		// pass nebula var to infinite Scroll
		//infiniteScroll(nebulaForScroll, i, minBpm, maxBpm);

		// remove body classes
		$('body').removeClass();
		// add body class 
		$('body').addClass(nebula);

		// populate new set of tracks
		populate(filterTracks, nebula);
		//callColorScheme(nebula);	
		console.log('*setCurrentNebula* - ' + nebula);

		
		
	}
				

	function applyColorScheme (event) {
		// smother over body and top nav background color
		$('body, .navbar.navbar-inverse.navbar-fixed-top').css('background-color', this.medium);
		// smother over text
		$('body, a.track-title, a.track-user-username').css('color', this.light);
		$('body .with-player').css('color', this.medium);
		$('.with-player a.track-title, .with-player a.track-user-username, .nebulas li a').css('color', this.dark);
		// smother over nebula buttons li items
		$('.nebulas li').css('background-color', this.light);
		// smother over current li with player
		$('#results li.with-player').css('background-color', '#eee');
		// smother over list elements
		$('#results li:not(".with-player")').css('background-color', this.dark);
		// smother over scrubber background image
		$('.sc-scrubber .sc-time-span img').css('background', 'url(' + this.nebula + ')' );
		// smother control 
		$('.sc-player .sc-controls a, .sc-player .sc-controls a:hover').css('background-color', this.dark);;

		console.log('*applyColorScheme* - color scheme applied.');	
	}

	colorScheme1.smother = applyColorScheme;
	colorScheme2.smother = applyColorScheme;
	colorScheme3.smother = applyColorScheme;
	colorScheme4.smother = applyColorScheme;
	colorScheme5.smother = applyColorScheme;
	colorScheme6.smother = applyColorScheme;
	colorScheme7.smother = applyColorScheme;
	colorScheme8.smother = applyColorScheme;
	colorScheme9.smother = applyColorScheme;
	colorScheme10.smother = applyColorScheme;

	function applyScrubberNebula () {
		// smother over scrubber background image
		$('.sc-scrubber .sc-time-span img').css('background', 'url(' + this.nebula + ')' );			
	}



	//colorScheme1.smother();

	function callColorScheme (nebula) {
		// //console.log(sliderValue);
		// //console.log(nebula);
		// if (nebula == 'orion') {
		// 	colorScheme1.smother();
		// };
		// if (nebula == 'carina') {
		// 	colorScheme2.smother();
		// };

		// if (nebula == 'eagle') {
		// 	colorScheme3.smother();
		// };

		// if (nebula == 'crab') {
		// 	colorScheme4.smother();
		// };
		// if (nebula == 'omega') {
		// 	colorScheme5.smother();
		// };
		// if (nebula == 'flame') {
		// 	colorScheme6.smother();
		// };
	}
		
	    // *******************************************************************


    	

    	/*
    	** Populate the tracks and embed widgets at will.
    	*/

    	function populate ( filterTracks, nebula) {
    		
    		console.log(nebula);
	    	// Get the tracks and embed the widget for every li element
		    SC.get('/tracks', filterTracks, function(tracks, error) {
			    $(tracks).each(function(index, track) {
			    	//console.log(track.track_type);

			    	if (error) { 
			    		//alert('Error: ' + error.message);
			    		$('#results').html('<div class="oops">Oops. There is a problem with teleportation probe. Please <a id="try-again" class="btn-try-again" href="#">try again</a> or select another nebula</div>'); 
			    		//$('#placeholder-wrapper .sc-player').remove();
			    	}


				    if (track.embeddable_by == 'all') {

			    	    $('#results').append($('<li class="track-' + index + '"></li>').html(

			    	    	'<a class="track-title" href="#" >' + track.title + '</a>' 
			    	  //   	+
			    			// ' Type: ' + track.track_type + ' - ' 
			    			// + 
			    			// ' Genre: ' + track.genre + ' - '
			    			+ 
			    			' by: <a class="track-user-username" href="' + track.user.permalink_url + '" target="_blank">' + track.user.username + '</a>'
			    			// +
			    			// '<br>'
			    			
			    			// ' Tags: ' + track.tag_list + ' - '
			    			// +
			    			// ' BPM: ' + track.bpm + ' - '
			    			+
			    			'<a href="' + track.permalink_url + '" target="_blank"><img class="sc-logo-dark" src="http://developers.soundcloud.com/assets/logo_big_black-75c05c178d54c50c8ff0afbb282d2c21.png" /></a>'
			    			+
			    			'<span class="permalink">' + track.permalink_url +'</span>'
			    	    // +
			    	    // '<a href="http://soundcloud.com/matas/hobnotropic" class="sc-player">My new dub track</a>'

			    	    ));
			    	    
			    	    // Declare $li variable		    	    
			    	    //var $li = track;				    		       			
				    };
				    console.log('tracks appended');
				  
			    });

		    	// var $trackItem = $('#results li');
		    	// $trackItem.each(function() {
		    	// 	var nexTrack = $(this).next('#results li');

		    	// })

				playFirstTrack(nebula);
				insertPlayerOnTitleClick();
				

		    	console.log(nebula);
		    	//callColorScheme(nebula);	

			});
				
			

		} // end populate ()



		function playFirstTrack (nebula) {
			// play the first track
			var $trackFirst = $('#results li:first');
			var permalinkTrackFirst = $trackFirst.find('.permalink').html();
			insertPlayer($trackFirst, permalinkTrackFirst, nebula);
			$trackFirst.addClass('with-player');
		}

		/*
		** Embed the Widget and Play next one when this one finishes
		*/

		function insertPlayer ($li, permalink, nebula) {

				console.log($li);
				// pause already playing player
				$('.playing a.sc-pause').click();

				//$li.css('background-color','#eee');
				// clear widget containers if there are widgets there already

				//$('#placeholder-wrapper').html('<div id="placeholder"></div>');

				//console.log(permalink);
				// append widget container with the widget
				if ($li.find('.widget-container').length < 1 ) {
					$li.append('<div class="widget-container"></div>');
				};

				//console.log($li[0].className);

				if ( $li.find('.sc-player.widget-container.playing').length < 1 ) {
					$.scPlayer.defaults.onDomReady = null;

					// remove existing player
					$('.sc-player:not("li.with-player .sc-player")').remove();

					// insert the player
					$('div.widget-container').scPlayer({
					  links: [{url: permalink, title: permalink}],
					  autoPlay  :   true
					  //randomize: true
					});
					$('.sc-logo-dark').hide();
					$li.find('.sc-logo-dark').show();

					// when player finishes playing click on next li to insert next player
					$(document).bind('scPlayer:onMediaEnd', function(event, track){						
					  $li.next('#results li').find('a.track-title').trigger('click'); 
					}); 
	
				}

				$('.sc-pause').removeClass('hidden');	

				paintScrubber(nebula);
		}


		//paintScrubber(nebula);
		function paintScrubber (nebula) {
			$(document).bind('onPlayerPlay.scPlayer', function(event){
			  callColorScheme(nebula);
			  console.log(nebula);
			});
		}

		//infinite scroll 

		// $('#results').infinitescroll({
		//   // other options
		//   dataType: 'json',
		//   appendCallback: false
		// }, function(json, opts) {
		//   // Get current page
		//   var page = opts.state.currPage; 
		//   // Do something with JSON data, create DOM elements, etc ..
		// });

		// function infiniteScroll (nebulaForScroll, i, minBpm, maxBpm) {

		// 	$(window).scroll(function(){				
		// 	    if($(window).scrollTop() == $(document).height() - $(window).height()) {
		// 	        $('div#loadmoreajaxloader').show();
		// 	        console.log('*infinteScroll* i before - ' + i);
		// 	        // set the maximum pages
		// 	        if (i > 10 ) {
		// 	        	//alert('you have reached the end of the universe');
		// 	        	$('div#loadmoreajaxloader').hide();

		// 	        	if ( $('#results .reached-end').length < 1 ) {
		// 	        		$('#results').append('<div class="reached-end">you have reached the end of the universe</div>');
		// 	        	};
			        	

		// 	        	return;     	
		// 	        };

		// 	        var filterTracksInfinite = {   
		// 	        			bpm: { from: minBpm, to: maxBpm }, 			        			
		// 	        			genres: 'psytrance',
		// 	        			limit: 2,
		// 	        			offset: i	
		// 	        			};
			       	
		// 	       	// Populate more tracks 
		// 	       	populate(filterTracksInfinite, nebulaForScroll, i);	
        	        
  //       	        //populate({offset : i});
  //       	        console.log('*infinteScroll* i after - ' + i);
		// 	       // Increment the index
		// 	       i = i+2;
		// 	       console.log('infiniteScrollNebula : ' + nebulaForScroll);
		// 	    } // end if			    		 
		// 	});
		// }

		function insertPlayerOnTitleClick () {
			// On track Title click
	    	$('#results li a.track-title').click(function (e) {
		    	e.preventDefault();
		    	console.log($li);

		    	// remove existing with-player classes
		    	$('#results li').removeClass('with-player');		    	

		    	var $li = $(this).parent('li');
		    	var permalink = $li.find('.permalink').html();
	    		// Embed the widget
	    		console.log($li);
	    		// add class with-player to this li
	    		$li.addClass('with-player');
	    		insertPlayer($li, permalink);
	    		//console.log($li);			    	
		    });
		}










		// Events/Actions

		//On Document Load
		//initially populate the tracks
		setCurrentNebula();

		// On Nebula Button Click 
		$('a.btn-nebula').click(function (e) {
			e.preventDefault();
			var $nebulaButton = $(this);		

			//remove existing current-nebula classes
			$('.nebulas li').removeClass('current-nebula');
			// add class current-nebula to the current button
			$nebulaButton.parent('li').addClass('current-nebula');

			setCurrentNebula();
			
		});

		
		


    	// On Try Again Click
	    $('#try-again').click(function (e) {
	    	e.preventDefault();
	    	// First, let's clear the area if there were previous results from other nebulas:
	    	//$('#results').html('');
	    	populate(filterTracks, nebula);	    		
	    });

		







		// $('#results').infinitescroll({
		// 	finished: console.log('kaka'),
			
		// });

		// $(document).endlessScroll({
		// 	loader: '<div class="loading">Loading<div>',
		// 	callback: function(nebula){
		// 	    alert(nebula);
		// 	    console.log(nebula);

		// 	  }

		// });


		
		


});
